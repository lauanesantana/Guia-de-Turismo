package com.example.guiaturismo

import android.os.Bundle
import android.widget.Adapter
import android.widget.ArrayAdapter
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.guiaturismo.databinding.ActivityMainBinding

    class MainActivity : AppCompatActivity() {

            private lateinit var binding: ActivityMainBinding
            private lateinit var adapter: ArrayAdapter<String>

            override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_main)
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

                binding = ActivityMainBinding.inflate(layoutInflater)
                setContentView(binding.root);
            }
        }
    }